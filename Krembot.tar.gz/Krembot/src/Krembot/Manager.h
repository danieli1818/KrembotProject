
#include "krembot.h"
//#include <string>
#include <map>
#include <unistd.h>

#define INTERVAL 1000

//using std::String;

class Manager {

  Krembot m_krembot;
  std::map<String, RGBASensor> rgbaSensors;
  std::map<String, int> directionsAngularSpeed;
  SandTimer m_publishTimer;
  int m_counter;

  String getShadowWay();
  void driveFromString(String direction);

public:
  Manager(Krembot& krembot);
  void doAction();
  ~Manager() = default;
};
