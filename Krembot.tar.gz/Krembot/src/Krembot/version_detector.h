#ifndef VERSION_DETECTOR_H
#define VERSION_DETECTOR_H

enum Version
{
  V1,
  V2
};

#endif
