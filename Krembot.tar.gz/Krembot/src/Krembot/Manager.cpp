
#include "Manager.h"

Manager::Manager(Krembot& krembot) {
  m_krembot = krembot;
  rgbaSensors["Front"] = m_krembot.RgbaFront;
  rgbaSensors["FrontRight"] = m_krembot.RgbaFrontRight;
  rgbaSensors["Right"] = m_krembot.RgbaRight;
  rgbaSensors["RearRight"] = m_krembot.RgbaRearRight;
  rgbaSensors["Rear"] = m_krembot.RgbaRear;
  rgbaSensors["RearLeft"] = m_krembot.RgbaRearLeft;
  rgbaSensors["Left"] = m_krembot.RgbaLeft;
  rgbaSensors["FrontLeft"] = m_krembot.RgbaFrontLeft;
  directionsAngularSpeed["Front"] = 0;
  directionsAngularSpeed["FrontRight"] = 45;
  directionsAngularSpeed["Right"] = 90;
  directionsAngularSpeed["RearRight"] = 135;
  directionsAngularSpeed["Rear"] = 180;
  directionsAngularSpeed["RearLeft"] = -135;
  directionsAngularSpeed["Left"] = -90;
  directionsAngularSpeed["FrontLeft"] = -45;
  m_counter = 0;
  m_publishTimer.start(INTERVAL);
}

String Manager::getShadowWay() {
  String shadowest = "Front";
  int shadowestValue = rgbaSensors[shadowest].readRGBA().Ambient;
  for (auto & element : rgbaSensors) {
      int currentValue = element.second.readRGBA().Ambient;
      if (currentValue < shadowestValue) {
        shadowest = element.first;
        shadowestValue = currentValue;
      }
  }
  if (m_publishTimer.finished()) {
    Particle.publish("action", String(shadowestValue), PUBLIC);
    m_publishTimer.startOver();
  }
  return shadowest;
}

void Manager::driveFromString(String direction) {
  if (directionsAngularSpeed.count(direction) == 1) {
    String str = "num ";
    str += m_counter;
    str += " : ";
    String publishStr = String(directionsAngularSpeed[direction]);
    publishStr = str + publishStr;
    if (m_publishTimer.finished()) {
      Particle.publish("action", publishStr, PUBLIC);
      m_publishTimer.startOver();
    }
    if (directionsAngularSpeed[direction] != 0) {
      if (directionsAngularSpeed[direction] > 100) {
        m_krembot.Base.drive(0, 100);
      } else if (directionsAngularSpeed[direction] < -100) {
        m_krembot.Base.drive(0, -100);
      } else {
        m_krembot.Base.drive(0, directionsAngularSpeed[direction]);
      }
    } else {
      m_krembot.Base.drive(100, 0);
    }
  } else {
    if (m_publishTimer.finished()) {
      Particle.publish("action", String("Didn't move"), PUBLIC);
      m_publishTimer.startOver();
    }
    //Particle.publish("action", String("Didn't move"), PUBLIC);
  }
  m_counter++;
}

void Manager::doAction() {
  //String publishStr("yay");
  //Particle.publish("action", publishStr, PUBLIC);
  String shadowWay = getShadowWay();
  driveFromString(shadowWay);
  //System.usleep(1000000);
  //usleep(1000000);
  //publishStr = String("yay");
  //Particle.publish("action", publishStr, PUBLIC);
}
